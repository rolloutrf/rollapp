import * as React from "react"

const MOBILE_BREAKPOINT = 768
const FINE_POINTER_QUERY = "(any-pointer: fine)"

export function useIsMobile() {
  const [isMobile, setIsMobile] = React.useState(undefined)

  React.useEffect(() => {
    const mql = window.matchMedia(`(max-width: ${MOBILE_BREAKPOINT - 1}px)`)
    const onChange = () => {
      setIsMobile(window.innerWidth < MOBILE_BREAKPOINT)
    }
    mql.addEventListener("change", onChange)
    setIsMobile(window.innerWidth < MOBILE_BREAKPOINT)
    return () => mql.removeEventListener("change", onChange);
  }, [])

  return !!isMobile
}

export function useHasFinePointer() {
  const [hasFinePointer, setHasFinePointer] = React.useState(() => (
    typeof window !== "undefined" && window.matchMedia(FINE_POINTER_QUERY).matches
  ))

  React.useEffect(() => {
    const mql = window.matchMedia(FINE_POINTER_QUERY)
    const onChange = () => setHasFinePointer(mql.matches)
    mql.addEventListener("change", onChange)
    onChange()
    return () => mql.removeEventListener("change", onChange)
  }, [])

  return hasFinePointer
}
